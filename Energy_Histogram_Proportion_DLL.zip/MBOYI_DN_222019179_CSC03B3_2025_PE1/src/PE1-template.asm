;	Update all of this information to reflect your own details and the practical
;	Author:	MBOYI DN 222019179
;	PE1 DLL starter file
.386
.MODEL FLAT, stdcall
.STACK 4096

.CODE

; LibMain function tests which action is currently beign performed
; The function returns if the DLL is loaded correctly or not.
; We avoid the complex logic here for simplicity.
LibMain proc instance:DWORD, reason:DWORD, unused:DWORD
mov eax, 1
ret
LibMain ENDP

histogram PROC NEAR32

PUSH EBP
MOV EBP, ESP
PUSH EBX
PUSh ECX
PUSH EDX
    
; Initialize bins array to 0
MOV EDX, [EBP+16]
MOV ECX, 16
    
LOOP_ONE:
MOV DWORD PTR [EDX], 0
ADD EDX, 4
LOOP LOOP_ONE
    
; Process energy values
MOV EBX, [EBP+8]
MOV ECX, [EBP+12]
CMP ECX, 0
JE DONEHISTOGRAM
    
PROCESSENERGY:
MOV EAX, [EBX]
; Ensure value is 0-15 using range checking (Option 8)
CMP EAX, 15
JBE VALUE_OK
MOV EAX, 15    ; Cap at maximum value if higher than 15

VALUE_OK:MOV EDX, [EBP+16]
    
; Calculate offset: bins[energy] address = bins + (energy * 4)
SHL EAX, 2
ADD EDX, EAX
    
; Increment the bin count
MOV EAX, [EDX]
INC EAX
MOV [EDX], EAX
    
ADD EBX, 4
loop PROCESSENERGY
    
DONEHISTOGRAM:
POP EDX
POP ECX
POP EBX
POP EBP
RET 12              ; Clean up 3 parameters
; TODO
histogram ENDP

proportion PROC NEAR32
PUSH EBP
MOV EBP, ESP
PUSH EAX
PUSH EBX
PUSH ECX
PUSH EDX
	
; Calculate total sum of all bins
mov ebx, [ebp+8]       ; ebx = pointer to bins array (1st parameter)
mov ecx, 16            ; 16 bins to sum
xor eax, eax           ; eax = total sum (initialize to 0)
	
sum_bins:
add eax, [ebx]         ; Add current bin value to total
add ebx, 4             ; Move to next bin
loop sum_bins          ; Repeat for all 16 bins
	
; Check if total is 0 to avoid division by zero
cmp eax, 0
je zero_total
	
; Save total for later use
mov [ebp-16], eax      ; Store total in local stack space
	
; Calculate proportions for each bin
mov ebx, [ebp+8]       ; ebx = pointer to bins array
mov edx, [ebp+12]      ; edx = pointer to ratio array (2nd parameter)
mov ecx, 16            ; 16 bins to process
	
calc_proportion:
push ecx               ; Save loop counter
push edx               ; Save ratio pointer
	
mov eax, [ebx]         ; eax = current bin value
imul eax, 100          ; eax = bin * 100
	
; Perform division: eax = (bin * 100) / total
mov ecx, [ebp-16]      ; ecx = total
xor edx, edx           ; Clear edx for division
idiv ecx               ; eax = (bin * 100) / total
	
pop edx                ; Restore ratio pointer
mov [edx], eax         ; Store percentage in ratio[i]
	
add ebx, 4             ; Move to next bin
add edx, 4             ; Move to next ratio element
	
pop ecx                ; Restore loop counter
loop calc_proportion   ; Repeat for all bins
	
jmp done_proportion
	
zero_total:
; If total is 0, set all ratios to 0
mov ebx, [ebp+12]      ; ebx = pointer to ratio array
mov ecx, 16
	
zero_ratios:
mov dword ptr [ebx], 0
add ebx, 4
loop zero_ratios
	
done_proportion:
pop edx
pop ecx
pop ebx
pop eax
pop ebp
ret
proportion ENDP
end LibMain
